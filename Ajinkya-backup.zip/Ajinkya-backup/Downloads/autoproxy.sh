function FindProxyForURL(url,host)
{

   // The DOMAINS listed in this array will be sent direct -- unproxied
   var direct_access_domains = new Array();
       direct_access_domains[0] = ".365wellst.com";
       direct_access_domains[1] = ".365wellstreet.com";
       direct_access_domains[2] = ".mymailpharmacy.com";
       direct_access_domains[3] = ".homeoffice.wal-mart.com";
       direct_access_domains[4] = ".easyrx.org";
       direct_access_domains[5] = ".medco-health.com";
       direct_access_domains[6] = ".medco.com";
       direct_access_domains[7] = ".medcohealth.com";
       direct_access_domains[8] = ".medcoonline.com";
       direct_access_domains[9] = ".medcorxdiscountprogram.com";
       direct_access_domains[10] = ".medcoyourplan.com";
       direct_access_domains[11] = ".medcoyourxplan.com";
       direct_access_domains[12] = ".medicationguidebook.com";
       direct_access_domains[13] = ".medicationguidebook.net";
       direct_access_domains[14] = ".medicationguidebook.org";
       direct_access_domains[15] = ".merck-medco.com";
       direct_access_domains[16] = ".merckmedco.com";
       direct_access_domains[17] = ".systemed.com";
       direct_access_domains[18] = ".tier-rx.com";
       direct_access_domains[19] = ".yourerxplan.com";
       direct_access_domains[20] = ".yourplan.com";
       direct_access_domains[21] = ".yourplandiscountcard.com";
       direct_access_domains[22] = ".yourrx.com";
       direct_access_domains[23] = ".yourrxplan.com";
       direct_access_domains[24] = ".yourxplan.com";
       direct_access_domains[25] = ".acsmedco.com";
       direct_access_domains[26] = ".acdo";
       direct_access_domains[27] = ".medcosurvey.com";
       direct_access_domains[28] = ".medcomedicare.com";
       direct_access_domains[29] = ".empireplanrxprogram.com";
       direct_access_domains[30] = ".ahi";
       direct_access_domains[31] = ".access-program.com";
       direct_access_domains[32] = ".accredo.acdo";
       direct_access_domains[33] = ".accredocbs.com";
       direct_access_domains[34] = ".accredo.com";
       direct_access_domains[35] = ".accredohealthgroup.com";
       direct_access_domains[36] = ".accredohealth.net";
       direct_access_domains[37] = ".accredonovafactor.com";
       direct_access_domains[38] = ".accredotx.com";
       direct_access_domains[39] = ".biopartnersincare.com";
       direct_access_domains[40] = ".bpc1.com";
       direct_access_domains[41] = ".childrenshemophilia.com";
       direct_access_domains[42] = ".clinicalbusinesssolutions.com";
       direct_access_domains[43] = ".factorcare.com";
       direct_access_domains[44] = ".hhcr.com";
       direct_access_domains[45] = ".hrahemo.com";
       direct_access_domains[46] = ".novafactor.com";
       direct_access_domains[47] = ".nutrepletion.com";
       direct_access_domains[48] = ".sunrisehm.com";
       direct_access_domains[49] = ".testacdo.com";
       direct_access_domains[50] = ".corp.polymedica.com";
       direct_access_domains[51] = ".medcospecialist.com";
       direct_access_domains[52] = ".medcospecialists.com";
       direct_access_domains[53] = ".local";
       direct_access_domains[54] = ".cvty.com";
       direct_access_domains[55] = ".cvtyapps.com";
       direct_access_domains[56] = ".choosemedco.com";
       direct_access_domains[57] = ".criticalcaresystems.com";
       direct_access_domains[58] = ".medcohealthstore.com";
       direct_access_domains[59] = ".dnadirect.com";
       direct_access_domains[60] = ".givehealthahand.org";
       direct_access_domains[61] = ".medsathome.com";
       direct_access_domains[62] = ".corp";
       direct_access_domains[63] = ".express-scripts.com";
       direct_access_domains[64] = "curascriptonline.com";
       direct_access_domains[65] = ".curascriptonline.com";
       direct_access_domains[66] = "curascript3pl.com";
       direct_access_domains[67] = ".curascript3pl.com";
       direct_access_domains[68] = ".freedomfertility.com";
       direct_access_domains[69] = "freedommedteach.com";
       direct_access_domains[70] = ".freedommedteach.com";
       direct_access_domains[71] = ".freedomdrug.com";
       direct_access_domains[72] = "healthbridgeinc.com";
       direct_access_domains[73] = ".healthbridgeinc.com";
       direct_access_domains[74] = "azandmeapp.com";
       direct_access_domains[75] = ".azandmeapp.com";
       direct_access_domains[76] = ".npcpapportal.com";
       direct_access_domains[77] = ".fertilityassist.com";
       direct_access_domains[78] = ".curascriptinfusion.com";
       direct_access_domains[79] = ".integrityhealthcare.com";
       direct_access_domains[80] = "curascriptsd.com";
       direct_access_domains[81] = ".curascriptsd.com";
       direct_access_domains[82] = "matrixoncology.com";
       direct_access_domains[83] = ".matrixoncology.com";
       direct_access_domains[84] = "carecontinuum.com";
       direct_access_domains[85] = ".carecontinuum.com";
       direct_access_domains[86] = "curascriptspecialtypharmacy.com";
       direct_access_domains[87] = ".curascriptspecialtypharmacy.com";
       direct_access_domains[88] = ".esicanada.ca";
       direct_access_domains[89] = ".express-scripts.ca";
       direct_access_domains[90] = ".csd.disa.mil";
       direct_access_domains[91] = ".esicp.dev";
       direct_access_domains[92] = ".esicp.ct";
       direct_access_domains[93] = ".esicp.corp";
       direct_access_domains[94] = ".ubcmain.com";
       direct_access_domains[95] = ".ubcpsc.com";
       direct_access_domains[96] = "matrix-oncology.com";
       direct_access_domains[97] = ".matrix-oncology.com";
       direct_access_domains[98] = "dataserv.us";
       direct_access_domains[99] = "dataserv-stl.com";
       direct_access_domains[100] = "dataservondemand.com";
       direct_access_domains[101] = "dataserv-test.com";
       direct_access_domains[102] = "starthomedelivery.com";
       direct_access_domains[103] = "matrixgpo.com";
       direct_access_domains[104] = ".matrixgpo.com";
       direct_access_domains[105] = "galileobi.com";
       direct_access_domains[106] = ".galileobi.com";
       direct_access_domains[107] = ".accredohealth.com";
       direct_access_domains[108] = ".proherant.com";
       direct_access_domains[109] = "express-scriptsmedicare.com";
       direct_access_domains[110] = ".express-scriptsmedicare.com";
       direct_access_domains[111] = "curascript.com";
       direct_access_domains[112] = ".curascript.com";

   // The HOSTS listed in this array will be sent direct -- unproxied
   var direct_access_hosts = new Array();
       direct_access_hosts[0] = "bgdevfs1.acsbghc.com"; // added 12.06.2005 as per Justin Sabino
       direct_access_hosts[1] = "dswebservices.one.microsoft.com";
       direct_access_hosts[2] = "licensing.microsoft.com";
       direct_access_hosts[3] = "fulfillment.usoc1.one.microsoft.com";
       direct_access_hosts[4] = "clientgateway.tmghealth.com";
       direct_access_hosts[5] = "webapps.criticalcaresystems.com";
       direct_access_hosts[6] = "accredo-fn.xdocs.com";
       direct_access_hosts[7] = "ftp.dms.vertisinc.com";
       direct_access_hosts[8] = "dnadirect.com";
       direct_access_hosts[9] = "admin.therapeasecuisine.com";
       direct_access_hosts[10] = "clientgatewayw.tmghealth.com";
       direct_access_hosts[11] = "cr-sgviewpt-01.apac.apaccs.com";
       direct_access_hosts[12] = "medco.destinationrx.com";
       direct_access_hosts[13] = "medsathome.com";
       direct_access_hosts[14] = "appsrv01a.amgen.com";
       direct_access_hosts[15] = "apptest17a.amgen.com";
       direct_access_hosts[16] = "collaboration.amgenpartners.com";
       direct_access_hosts[17] = "collaboration-test.amgenpartners.com";
       direct_access_hosts[18] = "edmprod1.amgen.com";
       direct_access_hosts[19] = "edmquality.amgen.com";
       direct_access_hosts[20] = "federation.amgen.com";
       direct_access_hosts[21] = "irpc.amgen.com";
       direct_access_hosts[22] = "irpc-dr.amgen.com";
       direct_access_hosts[23] = "irpcimcsrs.amgen.com";
       direct_access_hosts[24] = "irpcimcsrs-dr.amgen.com";
       direct_access_hosts[25] = "irpc-trn.amgen.com";
       direct_access_hosts[26] = "ism-sn.amgen.com";
       direct_access_hosts[27] = "lms.amgen.com";
       direct_access_hosts[28] = "login.amgen.com";
       direct_access_hosts[29] = "password.amgen.com";
       direct_access_hosts[30] = "passwordreset.amgen.com";
       direct_access_hosts[31] = "usri-rapp-rpc01.amgen.com";
       direct_access_hosts[32] = "usto-ddbx-ora17.amgen.com";
       direct_access_hosts[33] = "usto-dweb-iis01.amgen.com";
       direct_access_hosts[34] = "usto-papp-edm03.amgen.com";
       direct_access_hosts[35] = "usto-papp-edm11.amgen.com";
       direct_access_hosts[36] = "uswa-papp-rpc03.amgen.com";
       direct_access_hosts[37] = "uscallcenter.us-siebel.us-bos01.serono.com";
       direct_access_hosts[38] = "us1lh001.us-bos01.serono.com";
       direct_access_hosts[39] = "esi-prod-internal.pegacloud.com";
       direct_access_hosts[40] = "proherant.hostedcc.com";
       direct_access_hosts[41] = "tracker.stoneriver.com";
       direct_access_hosts[42] = "claimspro.cognizant.com";
       direct_access_hosts[43] = "edmdocuments.amgen.com";
       direct_access_hosts[44] = "edmcrf.amgen.com";
       direct_access_hosts[45] = "epic.amgen.com";
       direct_access_hosts[46] = "ecslogin.amgen.com";
       direct_access_hosts[47] = "ecslogin.amgenpartners.com";
       direct_access_hosts[48] = "kylexnc-hv5-cs.acsbps-ts.com";
       direct_access_hosts[49] = "tofa.unitedbiosource.com";
       direct_access_hosts[50] = "federation12.amgen.com";
       direct_access_hosts[51] = "login12.amgen.com";
       direct_access_hosts[52] = "intermuneae.com";
       direct_access_hosts[53] = "www.intermuneae.com";
       direct_access_hosts[54] = "training.intermuneae.com";
       direct_access_hosts[55] = "www.speedyreemployment.com";
       direct_access_hosts[56] = "www.esrx.com";
       direct_access_hosts[57] = "www.genericswork.com";
       direct_access_hosts[58] = "www.starthomedelivery.com";
       direct_access_hosts[59] = "www.starthomedelivery.net";
       direct_access_hosts[60] = "www.steptherapyfacts.com";
       direct_access_hosts[61] = "www.medcoresearchinstitute.com";
       direct_access_hosts[62] = "www.medcoresearch.com";
       direct_access_hosts[63] = "www.medcoresearch.org";
       direct_access_hosts[64] = "www.medcoresearchinstitute.org";
       direct_access_hosts[65] = "citrixvendor2.antheminc.com";
       direct_access_hosts[66] = "dsgnjuat.external.qg.com";
       direct_access_hosts[67] = "esrx.com";
       direct_access_hosts[68] = "www.esrx.com";
       direct_access_hosts[69] = "express-scripts.com";
       direct_access_hosts[70] = "expressscripts.com";
       direct_access_hosts[71] = "www.expressscripts.com";
       direct_access_hosts[72] = "therapeasecuisine.com";
       direct_access_hosts[73] = "www.therapeasecuisine.com";
       direct_access_hosts[74] = "medcoonline.com";

   // This is an associative array -- the network and mask are in separate arrays
   // Access to hosts inside the NETWORKS will be sent direct -- unproxied
   var direct_access_nets = new Array();
   var direct_access_mask = new Array();
       direct_access_nets[0] = "10.0.0.0";
       direct_access_mask[0] = "255.0.0.0";
       direct_access_nets[1] = "127.0.0.0";
       direct_access_mask[1] = "255.0.0.0";
       direct_access_nets[2] = "167.211.0.0";
       direct_access_mask[2] = "255.255.0.0";
       direct_access_nets[3] = "168.183.254.102";
       direct_access_mask[3] = "255.255.255.255";
       direct_access_nets[4] = "66.192.98.129";
       direct_access_mask[4] = "255.255.255.192";
       direct_access_nets[5] = "54.25.0.0";
       direct_access_mask[5] = "255.255.0.0";
       direct_access_nets[6] = "54.26.0.0";
       direct_access_mask[6] = "255.255.0.0";
       direct_access_nets[7] = "172.16.0.0";
       direct_access_mask[7] = "255.240.0.0";
       direct_access_nets[8] = "192.168.0.0";
       direct_access_mask[8] = "255.255.0.0";
       direct_access_nets[9] = "199.228.0.0";
       direct_access_mask[9] = "255.255.0.0";
       direct_access_nets[10] = "167.18.0.0";
       direct_access_mask[10] = "255.255.0.0";
       direct_access_nets[11] = "128.212.193.0";
       direct_access_mask[11] = "255.255.255.0";
       direct_access_nets[12] = "128.212.194.0";
       direct_access_mask[12] = "255.255.254.0";
       direct_access_nets[13] = "128.212.202.0";
       direct_access_mask[13] = "255.255.255.0";
       direct_access_nets[14] = "128.212.220.0";
       direct_access_mask[14] = "255.255.255.0";
       direct_access_nets[15] = "199.228.3.0";
       direct_access_mask[15] = "255.255.255.0";
       direct_access_nets[16] = "199.228.4.0";
       direct_access_mask[16] = "255.255.254.0";
       direct_access_nets[17] = "199.228.6.0";
       direct_access_mask[17] = "255.255.255.0";
       direct_access_nets[18] = "199.228.10.0";
       direct_access_mask[18] = "255.255.254.0";
       direct_access_nets[19] = "199.228.12.0";
       direct_access_mask[19] = "255.255.254.0";
       direct_access_nets[20] = "199.228.14.0";
       direct_access_mask[20] = "255.255.255.0";
       direct_access_nets[21] = "199.228.22.0";
       direct_access_mask[21] = "255.255.255.0";
       direct_access_nets[22] = "199.228.63.0";
       direct_access_mask[22] = "255.255.255.0";
       direct_access_nets[23] = "199.228.192.0";
       direct_access_mask[23] = "255.255.255.0";
       direct_access_nets[24] = "199.228.254.0";
       direct_access_mask[24] = "255.255.255.0";
       direct_access_nets[25] = "208.49.103.0";
       direct_access_mask[25] = "255.255.255.0";
       direct_access_nets[26] = "208.90.202.0";
       direct_access_mask[26] = "255.255.255.0";
       direct_access_nets[27] = "208.90.204.0";
       direct_access_mask[27] = "255.255.255.0";
       direct_access_nets[28] = "208.90.206.0";
       direct_access_mask[28] = "255.255.255.0";
       direct_access_nets[29] = "171.74.224.166";
       direct_access_mask[29] = "255.255.255.255";
       direct_access_nets[30] = "65.66.131.192";
       direct_access_mask[30] = "255.255.255.224";
       direct_access_nets[31] = "70.136.128.128";
       direct_access_mask[31] = "255.255.255.128";
       direct_access_nets[32] = "12.40.41.142";
       direct_access_mask[32] = "255.255.255.0";
       direct_access_nets[33] = "173.197.15.224";
       direct_access_mask[33] = "255.255.255.240";
       direct_access_nets[34] = "173.197.60.0";
       direct_access_mask[34] = "255.255.255.0";
       direct_access_nets[35] = "67.52.234.176";
       direct_access_mask[35] = "255.255.255.248";
       direct_access_nets[36] = "98.100.111.8";
       direct_access_mask[36] = "255.255.255.248";
       direct_access_nets[37] = "65.67.172.0";
       direct_access_mask[37] = "255.255.255.128";
       direct_access_nets[38] = "12.216.17.80";
       direct_access_mask[38] = "255.255.255.248";
       direct_access_nets[39] = "162.95.242.144";
       direct_access_mask[39] = "255.255.255.255";
       direct_access_nets[40] = "162.95.242.145";
       direct_access_mask[40] = "255.255.255.255";
       direct_access_nets[41] = "162.95.242.178";
       direct_access_mask[41] = "255.255.255.255";
       direct_access_nets[42] = "162.95.242.179";
       direct_access_mask[42] = "255.255.255.255";

   // Determine is the request being made is MMS protocol
   var mms_protocol = new Array();
       mms_protocol[0] = "mms:";

   // Determine is the request being made is RTSP protocol
   var rtsp_protocol = new Array();
       rtsp_protocol[0] = "rtsp:";

   // HOSTS in this array override all other logic in this script and are forced through Medco's Proxy
   var proxied_hosts = new Array();
       proxied_hosts[0] = "www.uhc.com";
       proxied_hosts[1] = "www.ingenix.com";
       proxied_hosts[2] = "www.provider.uhc.com";
       proxied_hosts[3] = "www.softlinkamerica.com";
       proxied_hosts[4] = "www.softlinkint.com";
       proxied_hosts[5] = "test.liberty3.net";
       proxied_hosts[6] = "downloads.liberty3.net";
       proxied_hosts[7] = "www.criticalcaresystems.com";
       proxied_hosts[8] = "criticalcaresystems.com";
       proxied_hosts[9] = "assistive.medcohealth.com";
       proxied_hosts[10] = "esqa.medcohealth.com";
       proxied_hosts[11] = "es.medcohealth.com";
       proxied_hosts[12] = "es1.medcohealth.com";
       proxied_hosts[13] = "unavailable.medcohealthstore.com";
       proxied_hosts[14] = "stats.medcohealthstore.com";
       proxied_hosts[15] = "sstats.medcohealthstore.com";
       proxied_hosts[16] = "reviews.medcohealthstore.com";
       proxied_hosts[17] = "answers.medcohealthstore.com";
       proxied_hosts[18] = "stories.medcohealthstore.com";
       proxied_hosts[19] = "smetrics.medcohealthstore.com";
       proxied_hosts[20] = "metrics.medcohealthstore.com";
       proxied_hosts[21] = "www2.medcohealth.com";
       proxied_hosts[22] = "mbm.accredo.com";
       proxied_hosts[23] = "es1uat.medsathome.com";
       proxied_hosts[24] = "es1uat.mymailpharmacy.com";
       proxied_hosts[25] = "esuat.medcohealth.com";
       proxied_hosts[26] = "es1.medsathome.com";
       proxied_hosts[27] = "es1.mymailpharmacy.com";
       proxied_hosts[28] = "es1uat.medcohealth.com";
       proxied_hosts[29] = "accessstl.express-scripts.com";
       proxied_hosts[30] = "ocs.express-scripts.com";
       proxied_hosts[31] = "pharmacy.express-scripts.com";
       proxied_hosts[32] = "pharma.express-scripts.com";
       proxied_hosts[33] = "reports.express-scripts.com";
       proxied_hosts[34] = "fileexchange.express-scripts.com";
       proxied_hosts[35] = "portal.express-scripts.com";
       proxied_hosts[36] = "lab.express-scripts.com";
       proxied_hosts[37] = "www2.express-scripts.com";
       proxied_hosts[38] = "mobile.express-scripts.com";
       proxied_hosts[39] = "ocsrp.express-scripts.com";
       proxied_hosts[40] = "rtc.express-scripts.com";
       proxied_hosts[41] = "trendcentral.express-scripts.com";
       proxied_hosts[42] = "careers.express-scripts.com";
       proxied_hosts[43] = "careersblog.express-scripts.com";
       proxied_hosts[44] = "directlink.express-scripts.com";
       proxied_hosts[45] = "www.accredo.com";
       proxied_hosts[46] = "staging-lab.express-scripts.com";
       proxied_hosts[47] = "qa-lab.express-scripts.com";
       proxied_hosts[48] = "www.lab.express-scripts.com";
       proxied_hosts[49] = "associate.express-scripts.com";
       proxied_hosts[50] = "oasis.express-scripts.com";
       proxied_hosts[51] = "es.accredo.com";
       proxied_hosts[52] = "healthbridge.express-scripts.com";
       proxied_hosts[53] = "healthbridgeanalytics.express-scripts.com";
       proxied_hosts[54] = "es.express-scripts.com";
       proxied_hosts[55] = "cn.accredo.com";
       proxied_hosts[56] = "zh-tw.accredo.com";
       proxied_hosts[57] = "zh-cn.accredo.com";
       proxied_hosts[58] = "esuat.express-scripts.com";
       proxied_hosts[59] = "assistive.express-scripts.com";
       proxied_hosts[60] = "my.express-scripts.com";
       proxied_hosts[61] = "pages.express-scripts.com";
       proxied_hosts[62] = "awt.accredo.com";
       proxied_hosts[63] = "mi.express-scripts.com";
       proxied_hosts[64] = "go.express-scripts.com";
       proxied_hosts[65] = "info.express-scripts.com";
       proxied_hosts[66] = "m.oasis.express-scripts.com";
       proxied_hosts[67] = "oasis-pilot.express-scripts.com";
       proxied_hosts[68] = "m.oasis-pilot.express-scripts.com";
       proxied_hosts[69] = "jobs.express-scripts.com";
       proxied_hosts[70] = "www.freedomfertility.com";
       proxied_hosts[71] = "freedomfertility.com";

   // DOMAINS in this array override all other logic in this script and are forced through Medco's Proxy
   var proxied_domains = new Array();
       proxied_domains[0] = ".email.medcohealthstore.com";
       proxied_domains[1] = "hcvcalculator.express-scripts.com";
       proxied_domains[2] = ".hcvcalculator.express-scripts.com";

   var fr_source_nets = new Array();
   var fr_source_mask = new Array();
       fr_source_nets[0] = "10.2.0.0"; // Franklin Lakes
       fr_source_mask[0] = "255.255.0.0";
       fr_source_nets[1] = "10.102.0.0"; // Franklin Lakes Wireless /18 supernet
       fr_source_mask[1] = "255.255.0.0";
       fr_source_nets[2] = "10.190.0.0"; // APAC
       fr_source_mask[2] = "255.255.0.0";
       fr_source_nets[3] = "10.60.32.0"; 
       fr_source_mask[3] = "255.255.255.0";
       fr_source_nets[4] = "10.60.180.0"; 
       fr_source_mask[4] = "255.255.255.0";
       fr_source_nets[5] = "10.80.11.0"; 
       fr_source_mask[5] = "255.255.255.0";
       fr_source_nets[6] = "10.26.1.0"; 
       fr_source_mask[6] = "255.255.255.0";
       fr_source_nets[7] = "10.60.32.0"; 
       fr_source_mask[7] = "255.255.255.0";
       fr_source_nets[8] = "10.7.51.0"; 
       fr_source_mask[8] = "255.255.0.0";
       fr_source_nets[9] = "10.60.0.0"; 
       fr_source_mask[9] = "255.255.255.0";
       fr_source_nets[10] = "10.60.24.0"; 
       fr_source_mask[10] = "255.255.255.0";
       fr_source_nets[11] = "10.9.0.0"; 
       fr_source_mask[11] = "255.255.0.0";
       fr_source_nets[12] = "10.1.88.0"; 
       fr_source_mask[12] = "255.255.255.0";

   var fl_source_nets = new Array();
   var fl_source_mask = new Array();
       fl_source_nets[0] = "10.1.0.0"; // Fairlawn
       fl_source_mask[0] = "255.255.0.0";
       fl_source_nets[1] = "10.101.0.0"; // Fairlawn Wireless /18 supernet
       fl_source_mask[1] = "255.255.0.0";
       fl_source_nets[2] = "10.150.0.0"; // IGSI & IGSB
       fl_source_mask[2] = "255.255.0.0";
       fl_source_nets[3] = "10.60.40.0"; 
       fl_source_mask[3] = "255.255.255.0";
       fl_source_nets[4] = "10.10.0.0"; 
       fl_source_mask[4] = "255.255.255.0";
       fl_source_nets[5] = "10.60.181.0"; 
       fl_source_mask[5] = "255.255.255.0";
       fl_source_nets[6] = "10.60.12.0"; 
       fl_source_mask[6] = "255.255.255.0";
       fl_source_nets[7] = "10.60.14.0"; 
       fl_source_mask[7] = "255.255.255.0";
       fl_source_nets[8] = "10.57.0.0"; 
       fl_source_mask[8] = "255.255.0.0";
       fl_source_nets[9] = "10.60.16.0"; 
       fl_source_mask[9] = "255.255.255.0";
       fl_source_nets[10] = "10.60.108.0"; 
       fl_source_mask[10] = "255.255.255.0";
       fl_source_nets[11] = "54.25.207.0"; 
       fl_source_mask[11] = "255.255.255.0";
       fl_source_nets[12] = "10.175.0.0"; 
       fl_source_mask[12] = "255.255.0.0";


   var mp_source_nets = new Array();
   var mp_source_mask = new Array();
       mp_source_nets[0] = "10.38.0.0"; // Accredo
       mp_source_mask[0] = "255.255.0.0";
       mp_source_nets[1] = "10.39.0.0"; // Medco RDC
       mp_source_mask[1] = "255.255.0.0";
       mp_source_nets[2] = "10.241.140.0";
       mp_source_mask[2] = "255.255.255.0";
       mp_source_nets[3] = "10.60.12.0"; 
       mp_source_mask[3] = "255.255.255.0";
       mp_source_nets[4] = "10.44.1.0";
       mp_source_mask[4] = "255.255.255.0";
       mp_source_nets[5] = "10.60.40.0";
       mp_source_mask[5] = "255.255.255.0";
       mp_source_nets[6] = "10.48.37.0";
       mp_source_mask[6] = "255.255.255.0";
       mp_source_nets[7] = "10.60.180.0";
       mp_source_mask[7] = "255.255.255.0";
       mp_source_nets[8] = "10.75.6.0";
       mp_source_mask[8] = "255.255.255.0";
       mp_source_nets[9] = "10.44.1.0";
       mp_source_mask[9] = "255.255.255.0";
       mp_source_nets[10] = "10.27.40.0";
       mp_source_mask[10] = "255.255.255.0";
       mp_source_nets[11] = "10.41.0.0";
       mp_source_mask[11] = "255.255.0.0";
       mp_source_nets[12] = "10.42.0.0";
       mp_source_mask[12] = "255.255.0.0";

   var hq_source_nets = new Array();
   var hq_source_mask = new Array();
       hq_source_nets[0] = "10.10.52.0"; 
       hq_source_mask[0] = "255.255.255.0";
       hq_source_nets[1] = "10.10.62.0"; 
       hq_source_mask[1] = "255.255.255.0";
       hq_source_nets[2] = "10.10.66.0"; 
       hq_source_mask[2] = "255.255.255.0";
       //hq_source_nets[3] = "10.11.0.0"; 
       //hq_source_mask[3] = "255.255.0.0";
       hq_source_nets[3] = "10.117.68.0"; 
       hq_source_mask[3] = "255.255.255.0";
       hq_source_nets[4] = "10.151.0.0"; 
       hq_source_mask[4] = "255.255.0.0";
       //hq_source_nets[6] = "10.4.0.0"; 
       //hq_source_mask[6] = "255.255.0.0";
       hq_source_nets[5] = "10.60.104.0"; 
       hq_source_mask[5] = "255.255.255.0";
       hq_source_nets[6] = "10.60.108.0"; 
       hq_source_mask[6] = "255.255.255.0";
       hq_source_nets[7] = "10.60.112.0"; 
       hq_source_mask[7] = "255.255.255.0";
       hq_source_nets[8] = "10.60.12.0"; 
       hq_source_mask[8] = "255.255.255.0";
       hq_source_nets[9] = "10.60.120.0"; 
       hq_source_mask[9] = "255.255.255.0";
       hq_source_nets[10] = "10.60.132.0"; 
       hq_source_mask[10] = "255.255.255.0";
       hq_source_nets[11] = "10.60.136.0"; 
       hq_source_mask[11] = "255.255.255.0";

   var ps2_source_nets = new Array();
   var ps2_source_mask = new Array();
       ps2_source_nets[0] = "10.221.0.0"; // Piscataway
       ps2_source_mask[0] = "255.255.0.0";

   var ch3_source_nets = new Array();
   var ch3_source_mask = new Array();
       ch3_source_nets[0] = "10.222.0.0"; // Chicago
       ch3_source_mask[0] = "255.255.0.0";

   // Initialize Variables
   var proxy_code = 0;
   var isnumeric = 0;
   var loc = 0;
   var myip="10.1.12.195";
   var prxy_site = 5;

   // evaluate source IP to determine if user should utilize a proxy in a particular site
   for (var i=0; i<fl_source_nets.length; i++) {
      if (isInNet(myip, fl_source_nets[i], fl_source_mask[i])) var loc = 2;
   }
   for (var i=0; i<fr_source_nets.length; i++) {
      if (isInNet(myip, fr_source_nets[i], fr_source_mask[i])) var loc = 2;
   }
   for (var i=0; i<mp_source_nets.length; i++) {
      if (isInNet(myip, mp_source_nets[i], mp_source_mask[i])) var loc = 1;
   }
   for (var i=0; i<hq_source_nets.length; i++) {
      if (isInNet(myip, hq_source_nets[i], hq_source_mask[i])) var loc = 1;
   }
   for (var i=0; i<ps2_source_nets.length; i++) {
      if (isInNet(myip, ps2_source_nets[i], ps2_source_mask[i])) var loc = 2;
   }
   for (var i=0; i<ch3_source_nets.length; i++) {
      if (isInNet(myip, ch3_source_nets[i], ch3_source_mask[i])) var loc = 1;
   }
   // perform site selection based upon the last digit of the client ip, if not hard coded to a particular site
   if (loc==0) {
      if (prxy_site<=5) var loc = 1; // Send to CH3
      if (prxy_site>=5) var loc = 2; // Send to PS2
   }
   // Site Selection
   var chicago = "ch3proxy.accounts.root.corp";
   var piscataway = "ps2proxy.accounts.root.corp";

   switch (loc){
   case 1:
      var primary = "ch3proxy.accounts.root.corp";
      var secondary = "ps2proxy.accounts.root.corp";
      break;
   case 2:
      var primary = "ps2proxy.accounts.root.corp";
      var secondary = "ch3proxy.accounts.root.corp";
      break;
   default :
      var primary = "ps2proxy.accounts.root.corp";
      var secondary = "ch3proxy.accounts.root.corp";
   }

   // MAIN SCRIPT LOGIC
   var proxy_code = 1;  //proxy code 1 = send to proxy server VIP
   for (var i=0; i<mms_protocol.length; i++) {
      if (url.substring(0, 4) == mms_protocol[i]) var proxy_code = 3; // proxy code 3 = send to mms proxy
   }
   for (var i=0; i<rtsp_protocol.length; i++) {
      if (url.substring(0, 5) == rtsp_protocol[i]) var proxy_code = 4; // proxy code 4 = send to rtsp proxy
   }
   for (var i=0; i<direct_access_domains.length; i++) {
      if (dnsDomainIs(host, direct_access_domains[i])) var proxy_code = 5; // proxy code 5 = send direct
   }
   for (var i=0; i<direct_access_hosts.length; i++) {
      if ( host == direct_access_hosts[i] ) var proxy_code = 5; // proxy code 5 = send direct
   }
   if (isPlainHostName(host)) var proxy_code = 5;
   var isnumeric = parseFloat(host.substring(0, 1));
   if ( isFinite(isnumeric) ) {
      for (var i=0; i<direct_access_nets.length; i++) {
         if (isInNet(host, direct_access_nets[i], direct_access_mask[i])) var proxy_code = 5; // proxy code 5 = send direct
      }
   }
   for (var i=0; i<proxied_hosts.length; i++) {
      if ( host == proxied_hosts[i] ) var proxy_code = 1; // proxy code 1 = override -- and use proxy
   }
   for (var i=0; i<proxied_domains.length; i++) {
      if (dnsDomainIs(host, proxied_domains[i])) var proxy_code = 1; // proxy code 1 = override -- and use proxy
   }

   //send Lync Skype traffic to DIRECT
   if (url.substring(0,29)=="https://lyncdiscoverinternal.") { var proxy_code = 3;}
   if (url.substring(0,28)=="http://lyncdiscoverinternal.") { var proxy_code = 3;}
   if (url.substring(0,21)=="https://lyncdiscover.") { var proxy_code = 3;}
   if (url.substring(0,20)=="https://rtcpool2.") { var proxy_code = 3;}
   if (url.substring(0,20)=="https://rtcpool3.") { var proxy_code = 3;}

   // END MAIN SCRIPT LOGIC
   // RETURN PROXY SPECIFICATION TO BROWSER
   switch (proxy_code){
   case 1: 
      return "PROXY "+primary+":8080; "+"PROXY "+secondary+":8080";
      break;
   case 3:
      return "DIRECT";
      break;
   case 4:
      return "DIRECT";
      break;
   case 5:
      return "DIRECT";
      break;
   case 6:
      return "PROXY "+piscataway+":8080; "+"PROXY "+piscataway+":8080";
      break;
   default : return "PROXY "+primary+":8080; "+"PROXY "+secondary+":8080";
   }
}
