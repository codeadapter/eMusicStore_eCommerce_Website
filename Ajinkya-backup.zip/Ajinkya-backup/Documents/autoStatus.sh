#!/bin/bash
localPATH=`pwd`
sep='----------------'
for d in */; do
  echo $sep " Status Of: " $d $sep
  d=`echo $d | sed s#/##`
  git -C $localPATH/$d status
  echo -e '\n'
done
