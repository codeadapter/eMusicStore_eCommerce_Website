package com.esrx.services.prescriber.transformer;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.converter.ConverterFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.stereotype.Component;

import com.esrx.services.prescriber.mapper.DateConverter;
import com.esrx.services.prescriber.mapper.ElectronicIndentifierPurposeConverter;
import com.esrx.services.prescriber.mapper.PrescriberAddressPurposeConverter;
import com.esrx.services.prescriber.mapper.StatusConverter;
import com.esrx.services.prescriber.mapper.TypeConverter;

@Component
public class MapperFactoryFactory implements FactoryBean<MapperFactory> {


	@Override
	public MapperFactory getObject() throws Exception {

		final MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

		ConverterFactory converterFactory = mapperFactory.getConverterFactory();
		converterFactory.registerConverter("dateFormatConverter", new DateConverter());
		converterFactory.registerConverter("statusFormatConverter", new StatusConverter());
		converterFactory.registerConverter("prescriberAddressPurposeConverter", new PrescriberAddressPurposeConverter());
        converterFactory.registerConverter("electronicIndentifierPurposeConverter", new ElectronicIndentifierPurposeConverter());
        converterFactory.registerConverter("typeFormatConverter", new TypeConverter());
        return mapperFactory;
	}

	@Override
	public Class<?> getObjectType() {
		return MapperFactory.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}
	
	
}
