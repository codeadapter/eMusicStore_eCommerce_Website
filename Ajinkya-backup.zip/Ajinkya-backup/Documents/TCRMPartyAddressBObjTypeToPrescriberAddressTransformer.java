package com.esrx.services.prescriber.transformer;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.esrx.services.core.transformer.Transformer;
import com.esrx.services.mdm.client.dto.xml.mdm.response.TCRMPartyAddressBObjType;
import com.esrx.services.prescriber.dto.json.PrescriberAddressDto;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;

@Component
public class TCRMPartyAddressBObjTypeToPrescriberAddressTransformer implements Transformer<TCRMPartyAddressBObjType,PrescriberAddressDto>{

	private MapperFacade mapperFacade;
	
	@Autowired
	public void setMapperFacade(MapperFactory mapperFactory) {
		this.mapperFacade = mapperFactory.getMapperFacade();

		mapperFactory.classMap(PrescriberAddressDto.class, TCRMPartyAddressBObjType.class).
				field("id", "addressId").
				field("addressLines[0]", "TCRMAddressBObj.addressLineOne").
				field("addressLines[1]", "TCRMAddressBObj.addressLineTwo").
				field("addressLines[2]", "TCRMAddressBObj.addressLineThree").
				fieldMap("startDate", "startDate").converter("dateFormatConverter").add().
				fieldMap("endDate", "endDate").converter("dateFormatConverter").add().
				field("county", "TCRMAddressBObj.countyCode").
				field("country", "TCRMAddressBObj.countryValue").
				field("locality", "TCRMAddressBObj.city").
				field("postalCode", "TCRMAddressBObj.zipPostalCode").
				field("postOfficeBoxNumber", "TCRMAddressBObj.zipPostalBarCode").
				fieldMap("purpose", "addressUsageValue").converter("prescriberAddressPurposeConverter").add().
				field("region", "TCRMAddressBObj.provinceStateValue").
				fieldMap("status", "TCRMAddressBObj.DWLStatus.status").converter("statusFormatConverter").add().
				byDefault().register();
	}

	@Override
	public PrescriberAddressDto transform(TCRMPartyAddressBObjType tcrmPartyAddressBObjType) {
		return mapperFacade.map(tcrmPartyAddressBObjType, PrescriberAddressDto.class);
	}
	

}
